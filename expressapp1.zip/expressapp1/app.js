
/**
 * Module dependencies.
 */

var express = require('express'),
http = require('http'),
path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.use(express.json());
app.use(express.bodyParser());
app.use(require('less-middleware')({ src: path.join(__dirname, 'public') }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'html');

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', function(req,res){
	res.sendfile('views/index.html');
});

/*app.get('/user/:userId', function(req,res){
	res.send('Hello '+req.params.userId+'!');
});*/

app.post('/user', function(req, res){
	res.send('we are creating user '+req.body.username);
});

app.get(/\/user\/([A-z]*)\/?(edit)?/, function(req, res){
	console.log(req.params[0]);
	if (req.params[1] === 'edit'){
		res.send('this is the editing page');
	} else {
		res.render('users.jade',{user:req.params[0]});
	}
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
